<?php $__env->startSection('title', 'Заказ'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="justify-content-center">
        <div class="panel">
            <h1>Заказ №<?php echo e($order->id); ?></h1>
            <p>Заказчик: <b><?php echo e($order->name); ?></b></p>
            <p>Номер телефона: <b><?php echo e($order->phone); ?></b></p>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Название</th>
                    <th>Кол-во</th>
                    <th>Цена</th>
                    <th>Стоимость</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>">
                                <img height="56px" src="
                                    <?php if($product->img): ?>
                                <?php echo e(Storage::url($product->img)); ?>

                                <?php else: ?>
                                <?php echo e(asset('img/placeholder.jpg')); ?>

                                <?php endif; ?>">
                                <?php echo e($product->name); ?>

                            </a>
                        </td>
                        <td><span class="badge"> <?php echo e($product->pivot->count); ?></span></td>
                        <td><?php echo e($product->price); ?> руб.</td>
                        <td><?php echo e($product->get_sum_price()); ?> руб.</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="3">Общая стоимость:</td>
                    <td><b><?php echo e($order->get_total_price()); ?> руб.</b></td>
                </tr>
                </tbody>
            </table>
            <br>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/admin/orders/order.blade.php ENDPATH**/ ?>