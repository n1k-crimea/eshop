<div class="col-md-4">
    <div class="card mb-4 box-shadow">
        <img class="card-img-top img_card"  alt="Card image cap" src="
            <?php if($product->img): ?>
                <?php echo e(Storage::url($product->img)); ?>

            <?php else: ?>
                <?php echo e(asset('img/placeholder.jpg')); ?>

            <?php endif; ?>
        ">
        <div class="card-body">
            <text class="text-muted"><?php echo e($product->category->name); ?></text>
            <h3 class="card-title"><?php echo e($product->name); ?></h3>
            <p class="card-text"><?php echo e($product->desc); ?></p>
            <div class="d-flex justify-content-between align-items-center">
                <div class="btn-toolbar">
                    <a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>" class="btn btn-sm btn-outline-primary">Просмотр</a>
                    <form action="<?php echo e(route('cart_add', $product)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-outline-success">В корзину</button>
                    </form>
                </div>
                <text class="text-muted"><?php echo e($product->price); ?> руб.</text>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/nik/php-work/eshop/resources/views/card.blade.php ENDPATH**/ ?>