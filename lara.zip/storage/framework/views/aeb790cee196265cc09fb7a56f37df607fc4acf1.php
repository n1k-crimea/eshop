<?php $__env->startSection('title', 'Заказ'); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb">
        <h2>Заказ</h2>
    </div>
        <h2>На сумму: <b><?php echo e($order->get_total_price()); ?> руб.</b></h2>
        <p>Для оформления заказа заполните форму. Мы свяжемся с вами по указанным данным.</p>
        <div class="row justify-content-center">
            <form action="<?php echo e(route('cart_confirm')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                        <div class="form-group">
                            <label for="name" class="control-label col-lg-offset-3 col-lg-2">Имя*</label>
                            <div>
                                <input type="text" name="name" id="name" value="" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone" class="control-label col-lg-offset-3 col-lg-2">Телефон</label>
                            <div>
                                <input type="number" name="phone" id="phone" value="" class="form-control">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone" class="control-label col-lg-offset-3 col-lg-2">E-mail*</label>
                            <div>
                                <input type="email" name="email" id="email" value="" class="form-control" required>
                            </div>
                        </div>
                    <input type="submit" class="btn btn-success" value="Подтвердить заказ">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/order.blade.php ENDPATH**/ ?>