<?php $__env->startSection('title', 'Все категории'); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb">
        <h2>Все категории</h2>
    </div>
    <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 box-shadow">
                        <img class="card-img-top img_card" alt="Card image cap" src="
                            <?php if($category->img): ?>
                                <?php echo e(Storage::url($category->img)); ?>

                            <?php else: ?>
                                <?php echo e(asset('img/placeholder.jpg')); ?>

                            <?php endif; ?>
                        ">
                        <div class="card-body">
                            <h5 class="card-title"><a href="/<?php echo e($category->code); ?>"><?php echo e($category->name); ?></a></h5>
                            <p class="card-text"><?php echo e($category->desc); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/categories.blade.php ENDPATH**/ ?>