<?php $__env->startSection('title', 'Редактировать товар'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
            <h1>Редактировать товар <b><?php echo e($product->name); ?></b></h1>
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('products.update', $product)); ?>">
            <div>
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Код: </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="code" id="code"
                               value="<?php echo e($product->code); ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Название: </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" id="name"
                               value="<?php echo e($product->name); ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="category_id" class="col-sm-2 col-form-label">Категория: </label>
                    <div class="col-sm-6">
                        <select name="category_id" id="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php if($product->category_id == $category->id): ?>
                                        selected
                                    <?php endif; ?>
                                ><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description" class="col-sm-2 col-form-label">Описание: </label>
                    <div class="col-sm-6">
								<textarea name="desc" id="description" cols="72"
                                          rows="7"><?php echo e($product->desc); ?></textarea>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="image" class="col-sm-2 col-form-label">Текущее изображение: </label>
                    <div class="col-sm-10">
                        <img src="<?php echo e(Storage::url($product->img)); ?>" height="64px">
                    </div>
                </div>
                <div class="input-group row">
                    <label for="image" class="col-sm-2 col-form-label">Загрузить новое изображение: </label>
                    <div class="col-sm-10">
                        <label class="btn btn-default btn-file">
                            <input type="file" name="img" id="image">
                        </label>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="price" class="col-sm-2 col-form-label">Цена: </label>
                    <div class="col-sm-2">
                        <input type="text" class="form-control" name="price" id="price"
                               value="<?php echo e($product->price); ?>">
                    </div>
                </div>
                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/admin/products/edit_product.blade.php ENDPATH**/ ?>