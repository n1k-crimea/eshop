<?php $__env->startSection('title', 'Товар'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <h1><?php echo e($product->name); ?></h1>
        <p>
        <div class="btn-group" role="group">
            <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST">
                <a class="btn btn-warning" type="button"
                   href="<?php echo e(route('products.edit', $product)); ?>">Редактировать</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input class="btn btn-danger" type="submit" value="Удалить" onclick="return confirmDelete()">
            </form>
        </div>
        </p>
        <table class="table">
            <tbody>
            <tr>
                <th>
                    Поле
                </th>
                <th>
                    Значение
                </th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($product->id); ?></td>
            </tr>
            <tr>
                <td>Код</td>
                <td><?php echo e($product->code); ?></td>
            </tr>
            <tr>
                <td>Название</td>
                <td><?php echo e($product->name); ?></td>
            </tr>
            <tr>
                <td>Описание</td>
                <td><?php echo e($product->desc); ?></td>
            </tr>
            <tr>
                <td>Изображение</td>
                <td><img src="<?php echo e(Storage::url($product->img)); ?>" height="240px"></td>
            </tr>
            <tr>
                <td>Категория</td>
                <td><?php echo e($product->category->name); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/admin/products/product.blade.php ENDPATH**/ ?>