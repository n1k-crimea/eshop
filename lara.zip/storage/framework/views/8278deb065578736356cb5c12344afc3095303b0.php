<?php $__env->startSection('title', 'Товар: '.$product->name); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb">
        <h2><?php echo e($product->name); ?></h2>
    </div>
    <div class="row">
            <table class="table my-table" >
                <tbody>
                <tr>
                    <td>Цена</td>
                    <td><?php echo e($product->price); ?> руб.</td>
                </tr>
                <tr>
                    <td>Название</td>
                    <td><?php echo e($product->name); ?></td>
                </tr>
                <tr>
                    <td>Описание</td>
                    <td><?php echo e($product->desc); ?></td>
                </tr>
                <tr>
                    <td>Изображение</td>
                    <td><img src="
                        <?php if($product->img): ?>
                            <?php echo e(Storage::url($product->img)); ?>

                        <?php else: ?>
                            <?php echo e(asset('img/placeholder.jpg')); ?>

                        <?php endif; ?>"
                             height="240px">
                    </td>
                </tr>
                <tr>
                    <td>
                        <form action="<?php echo e(route('cart_add', $product)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">В корзину</button>
                        </form>
                    </td>
                    <td></td>
                </tr>
                </tbody>
            </table>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/product.blade.php ENDPATH**/ ?>