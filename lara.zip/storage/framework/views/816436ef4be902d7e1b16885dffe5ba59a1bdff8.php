<?php $__env->startSection('title', 'Корзина'); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb">
        <h2>Корзина</h2>
    </div>
    <div class="row">
            <table class="table">
                <thead>
                <tr>
                    <th>название</th>
                    <th>количество</th>
                    <th>цена</th>
                    <th>всего</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>">
                                <img height="56px" src="
                                    <?php if($product->img): ?>
                                        <?php echo e(Storage::url($product->img)); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('img/placeholder.jpg')); ?>

                                    <?php endif; ?>">
                                <?php echo e($product->name); ?>

                            </a>
                        </td>
                        <td><span class="badge"><?php echo e($product->pivot->count); ?></span>
                            <div class="btn-group form-inline">
                                <form action="<?php echo e(route('cart_del', $product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger" href="">
                                        <span class="glyphicon glyphicon-minus" aria-hidden="true">-</span>
                                    </button>
                                </form>
                                <form action="<?php echo e(route('cart_add', $product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success" href="">
                                        <span class="glyphicon glyphicon-plus" aria-hidden="true">+</span></button>
                                </form>
                            </div>
                        </td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->get_sum_price()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td colspan="3">всего</td>
                    <td><?php echo e($order->get_total_price()); ?></td>
                </tr>
                </tbody>
            </table>
            <br>
            <div class="btn-group pull-right" role="group">
                <a type="button" class="btn btn-success" href="<?php echo e(route('cart_order')); ?>">заказать</a>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/cart.blade.php ENDPATH**/ ?>