<?php $__env->startSection('title', 'Категория'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <h1>Категория Бытовая техника</h1>
        <p>
        <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST">
            <a class="btn btn-warning" type="button" href="<?php echo e(route('categories.edit', $category)); ?>">Редактировать</a>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input class="btn btn-danger" type="submit" value="Удалить" onclick="return confirm('Вы подтверждаете удаление?')">
        </form>
        </p>
        <table class="table">
            <tbody>
            <tr>
                <th>
                    Поле
                </th>
                <th>
                    Значение
                </th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($category->id); ?></td>
            </tr>
            <tr>
                <td>Код</td>
                <td><?php echo e($category->code); ?></td>
            </tr>
            <tr>
                <td>Название</td>
                <td><?php echo e($category->name); ?></td>
            </tr>
            <tr>
                <td>Описание</td>
                <td><?php echo e($category->desc); ?></td>
            </tr>
            <tr>
                <td>Изображение</td>
                <td><img src="<?php echo e(Storage::url($category->img)); ?>" height="240px"></td>
            </tr>
            <tr>
                <td>Кол-во товаров</td>
                <td><?php echo e($category->products->count()); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nik/php-work/eshop/resources/views/admin/categories/category.blade.php ENDPATH**/ ?>